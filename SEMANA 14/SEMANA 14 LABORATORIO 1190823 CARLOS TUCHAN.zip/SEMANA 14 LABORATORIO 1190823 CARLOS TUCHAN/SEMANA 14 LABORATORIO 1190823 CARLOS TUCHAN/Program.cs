﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEMANA_14_LABORATORIO_1190823_CARLOS_TUCHAN
{
    internal class Program
    {
        static void Main(string[] args)
        { 
                do
                {
                    int[] numeros = new int[7];
                    int numeroMayor = int.MinValue;
                    int numeroMenor = int.MaxValue;
                    int positivos = 0;
                    int negativos = 0;

                    Console.WriteLine("ingresar 7 números enteros:");

                    for (int i = 0; i < 7; i++)
                    {
                        Console.Write($"Número {i + 1}: ");
                        if (int.TryParse(Console.ReadLine(), out numeros[i]))
                        {
                            if (numeros[i] > numeroMayor)
                            {
                                numeroMayor = numeros[i];
                            }
                            if (numeros[i] < numeroMenor)
                            {
                                numeroMenor = numeros[i];
                            }
                            if (numeros[i] > 0)
                            {
                                positivos++;
                            }
                            else if (numeros[i] < 0)
                            {
                                negativos++;
                            }
                        }
                        else
                        {
                            Console.WriteLine("error, ingrese un número valido.");
                            i--;
                        }
                    }

                    Console.WriteLine($"el número mayor es: {numeroMayor}");
                    Console.WriteLine($"el número menor es: {numeroMenor}");
                    Console.WriteLine($"hay {positivos} números positivos ");
                    Console.WriteLine($"hay {negativos} números negativos");

                    Console.Write("¿se desea ingresar otra secuencia de números? (si o no): ");
                    string respuesta = Console.ReadLine().Trim();

                    if (respuesta.Equals("no", StringComparison.OrdinalIgnoreCase))
                    {
                        Console.WriteLine("los números ingresados son:");
                        foreach (int num in numeros)
                        {
                            Console.Write(num + " ");
                        }
                        break;
                    }

                } while (true);
            }
        }

    }


