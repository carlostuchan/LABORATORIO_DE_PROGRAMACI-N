﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T1_CJTH1190823
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("mi segundo programa");
            Console.WriteLine("ingrese su nombre: ");
            string Nombre2 = Console.ReadLine();
            Console.WriteLine("ingrese su edad: ");
            string edad = Console.ReadLine();
            Console.WriteLine("Ingrese su carrera: ");
            string carrera = Console.ReadLine();
            Console.WriteLine("ingrese su carné: ");
            string carné = Console.ReadLine();

            Console.Write("Nombre: " + Nombre2);
            Console.Write("edad: " + edad);
            Console.Write("carrera: " + carrera);
            Console.Write("carné: " + carné);
            Console.WriteLine(" soy " + Nombre2 + "tengo " + edad + "años y estudio la carrera de" + carrera + "y mi carné es " + carné);
             

        }
    }
}
