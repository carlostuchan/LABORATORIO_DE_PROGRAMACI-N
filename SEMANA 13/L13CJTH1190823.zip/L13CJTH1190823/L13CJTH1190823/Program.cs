﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L13CJTH1190823
{
    internal class Program
    {
        
            static double[] notas = new double[8];

            static void Main(string[] args)
            {
                    for (int i = 0; i < 8; i++)
                    {
                        Console.Write("Ingrese nota del laboratorio " + (i + 1) + ": ");
                        notas[i] = Convert.ToDouble(Console.ReadLine());
                    }

                    double suma = 0;
                    for (int i = 0; i < 8; i++)
                    {
                        suma += notas[i];
                    }
                    double promedio = suma / 8;

                    Console.WriteLine("El promedio de las notas de laboratorio es: " + promedio);

                    double notaMax = notas[0];
                    for (int i = 1; i < 8; i++)
                    {
                        if (notas[i] > notaMax)
                        {
                            notaMax = notas[i];
                        }
                    }

                    Console.WriteLine("La nota más alta en laboratorio de programación es: " + notaMax);

                    Console.WriteLine("Ingrese una palabra:");
                    string palabra = Console.ReadLine();

                    Console.WriteLine("Ingrese una letra:");
                    string letraInput = Console.ReadLine();

                    if (letraInput.Length == 1)
                    {
                        char letra = letraInput[0];

                        char[] vector_palabra = palabra.ToCharArray();

                        int cantidadDeVeces = 0;

                        for (int i = 0; i < palabra.Length; i++)
                        {
                            if (vector_palabra[i] == letra)
                            {
                                cantidadDeVeces++;
                            }
                        }

                        Console.WriteLine("Cantidad de veces que la letra '" + letra + "' aparece en la palabra: " + cantidadDeVeces);
                    }
                    else
                    {
                        Console.WriteLine("Debe ingresar una sola letra.");
                    }
                }
            }

        }
    

        









