﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T4CJTH1190823E2

{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Jorge López - 1422616");
            Console.WriteLine("Calculadora de Billetes y Monedas en Quetzales");
            Console.WriteLine();

            // Solicitar al usuario ingresar una cantidad en quetzales
            Console.Write("Ingrese un número (entre 0 y 999.99) en quetzales: ");
            if (double.TryParse(Console.ReadLine(), out double cantidad))
            {
                if (cantidad >= 0 && cantidad <= 999.99)
                {
                    // Convertir la cantidad a centavos para facilitar el cálculo
                    int centavos = (int)(cantidad * 100);

                    // Definir las denominaciones de billetes y monedas
                    int[] denominaciones = { 10000, 5000, 2000, 1000, 500, 100, 25, 1 };
                    string[] nombres = { "Q 100", "Q 50", "Q 20", "Q 10", "Q 5", "Q 1", "25 centavos", "1 centavo" };

                    Console.WriteLine("Equivalencia en billetes y monedas:");

                    for (int i = 0; i < denominaciones.Length; i++)
                    {
                        int cantidadDenominacion = centavos / denominaciones[i];
                        centavos %= denominaciones[i];

                        if (cantidadDenominacion > 0)
                        {
                            Console.WriteLine($"{cantidadDenominacion} de {nombres[i]}");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Error: La cantidad debe estar entre 0 y 999.99 quetzales.");
                }
            }
            else
            {
                Console.WriteLine("Error: Ingrese un valor numérico válido.");
            }

            Console.ReadLine();
        }
    }
}
