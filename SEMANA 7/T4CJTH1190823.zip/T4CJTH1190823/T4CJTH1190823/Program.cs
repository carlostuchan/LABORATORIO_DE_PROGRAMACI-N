﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T4CJTH1190823
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Calculadora de Movimiento Rectilíneo Uniformemente Variado");
            Console.WriteLine("Ingrese tres de las cuatro variables para calcular la cuarta.");
            Console.WriteLine();

            double vFinal = 0, vInicial = 0, aceleracion = 0, tiempo = 0;

            Console.Write("Ingrese la velocidad final (Vf): ");
            if (double.TryParse(Console.ReadLine(), out vFinal))
            {
                Console.Write("Ingrese la velocidad inicial (V0): ");
                if (double.TryParse(Console.ReadLine(), out vInicial))
                {
                    Console.Write("Ingrese la aceleración (a): ");
                    if (double.TryParse(Console.ReadLine(), out aceleracion))
                    {
                        Console.Write("Ingrese el tiempo (t): ");
                        if (double.TryParse(Console.ReadLine(), out tiempo))
                        {
                            Console.WriteLine("Error: No puede ingresar todas las variables o ninguna.");
                        }
                        else
                        {
                            tiempo = (vFinal - vInicial) / aceleracion;
                            Console.WriteLine($"El tiempo (t) es igual a: {tiempo}");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error: Debe ingresar valores numéricos.");
                    }
                }
                else
                {
                    Console.WriteLine("Error: Debe ingresar valores numéricos.");
                }
            }
            else
            {
                Console.WriteLine("Error: Debe ingresar valores numéricos.");
            }

            Console.ReadLine();
        }
    }
}
