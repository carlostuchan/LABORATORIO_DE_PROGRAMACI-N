﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T9CJTH1190823
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese un número entero mayor que 0: ");
            int N = int.Parse(Console.ReadLine());

            if (N > 0)
            {
                // Calculando la serie a
                double serieA = 0.0;
                for (int i = 1; i <= N; i++)
                {
                    serieA += 1.0 / i;
                }

                // Calculando la serie b
                double serieB = 0.0;
                for (int i = 1; i <= N; i++)
                {
                    serieB += 1.0 / Math.Pow(2, i);
                }

                Console.WriteLine("Serie a: " + serieA);
                Console.WriteLine("Serie b: " + serieB);
            }
            else
            {
                Console.WriteLine("El número debe ser mayor que 0.");
            }

            Console.ReadLine();
        }
    }
}
