﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T10CJTH1190823
{
        class TrianguloRectangulo
        {
            private double catetoA;
            private double anguloOpuestoA;

            public void SetCatetoA(double value)
            {
                catetoA = value;
            }

            public void SetAnguloOpuestoA(double value)
            {
                anguloOpuestoA = value;
            }

            public double ObtenerCatetoA()
            {
                return catetoA;
            }

            public double ObtenerCatetoB()
            {
                return catetoA * Math.Tan(anguloOpuestoA * (Math.PI / 180));
            }

            public double ObtenerHipotenusa()
            {
                return catetoA / Math.Sin(anguloOpuestoA * (Math.PI / 180));
            }

            public double ObtenerAnguloOpuestoA()
            {
                return anguloOpuestoA;
            }

            public double ObtenerAnguloOpuestoB()
            {
                return 90 - anguloOpuestoA;
            }

            public double ObtenerArea()
            {
                return 0.5 * catetoA * ObtenerCatetoB();
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("Triángulo Rectángulo Calculator");
                Console.WriteLine("-------------------------------");

                TrianguloRectangulo objTriangulo = new TrianguloRectangulo();

                Console.Write("Ingrese la longitud del cateto A (en metros): ");
                double catetoA = Convert.ToDouble(Console.ReadLine());
                objTriangulo.SetCatetoA(catetoA);

                Console.Write("Ingrese el ángulo opuesto al cateto A (en grados): ");
                double anguloOpuestoA = Convert.ToDouble(Console.ReadLine());
                objTriangulo.SetAnguloOpuestoA(anguloOpuestoA);

                Console.WriteLine("\nResultados:");
                Console.WriteLine("Cateto A: {0:0.000}", objTriangulo.ObtenerCatetoA());
                Console.WriteLine("Cateto B: {0:0.000}", objTriangulo.ObtenerCatetoB());
                Console.WriteLine("Hipotenusa: {0:0.000}", objTriangulo.ObtenerHipotenusa());
                Console.WriteLine("Ángulo Opuesto A: {0:0.000} grados", objTriangulo.ObtenerAnguloOpuestoA());
                Console.WriteLine("Ángulo Opuesto B: {0:0.000} grados", objTriangulo.ObtenerAnguloOpuestoB());
                Console.WriteLine("Área: {0:0.000}", objTriangulo.ObtenerArea());
            }
        }
    }

