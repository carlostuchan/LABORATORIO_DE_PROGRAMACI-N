﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10CJTH1190823
{
    class Circulo
    {
        private double radio;

        public Circulo(double radio)
        {
            this.radio = radio;
        }

        private double ObtenerPerimetro()
        {
            return 2 * Math.PI * radio;
        }

        private double ObtenerArea()
        {
            return Math.PI * radio * radio;
        }

        private double ObtenerVolumen()
        {
            return (4 * Math.PI * Math.Pow(radio, 3)) / 3;
        }

        public void CalcularGeometria(ref double unPerimetro, ref double unArea, ref double unVolumen)
        {
            unPerimetro = ObtenerPerimetro();
            unArea = ObtenerArea();
            unVolumen = ObtenerVolumen();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese el radio del círculo: ");
            double radio = Convert.ToDouble(Console.ReadLine());

            Circulo objCirculo = new Circulo(radio);

            double perimetro = 0;
            double area = 0;
            double volumen = 0;

            objCirculo.CalcularGeometria(ref perimetro, ref area, ref volumen);

            Console.WriteLine("Perímetro del círculo: " + perimetro);
            Console.WriteLine("Área del círculo: " + area);
            Console.WriteLine("Volumen de la esfera: " + volumen);
        }
    }

}
